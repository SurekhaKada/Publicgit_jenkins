package com.example.SampleWebonly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleWebonlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
