package com.example.SampleWebonly;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MsgPost_GetUsername {

    @PostMapping("/greet")
    public ResponseEntity<String> greetUser(@RequestBody User user) {
        String message = "Hello, " + user.getName() + "! Welcome to our platform.";
        return ResponseEntity.status(HttpStatus.OK).body(message);
    }
}
