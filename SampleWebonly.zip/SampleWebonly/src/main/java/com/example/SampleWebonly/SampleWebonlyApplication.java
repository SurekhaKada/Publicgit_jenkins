package com.example.SampleWebonly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleWebonlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleWebonlyApplication.class, args);
	}

}
