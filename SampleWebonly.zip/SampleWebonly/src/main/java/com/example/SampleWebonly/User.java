package com.example.SampleWebonly;


public class User {
    private String name;

	public String getName() {
		
		return name;
	}

    // Getter and setter for 'name'
}
